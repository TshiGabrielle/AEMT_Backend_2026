package com.helha.backend.Application.folders.getAll;

// données nécessaires pour récupérer l'arborescence
public record GetFoldersTreeInput(
        //long userId id de l'utilisateur (en attendant l'auth)
) {}
