package com.helha.backend.Application.folders.rename;

// résultat après renommage
public record RenameFolderOutput(
        boolean success,
        String message
) {}
