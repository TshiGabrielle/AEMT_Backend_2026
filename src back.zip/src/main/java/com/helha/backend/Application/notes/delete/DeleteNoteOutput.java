package com.helha.backend.Application.notes.delete;

public record DeleteNoteOutput(
        boolean success
) {}
