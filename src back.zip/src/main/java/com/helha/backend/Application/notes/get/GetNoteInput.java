package com.helha.backend.Application.notes.get;

public record GetNoteInput(
        long id
) {
}
