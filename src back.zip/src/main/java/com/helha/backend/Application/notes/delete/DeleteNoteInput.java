package com.helha.backend.Application.notes.delete;

public record DeleteNoteInput (
        long id
){}
