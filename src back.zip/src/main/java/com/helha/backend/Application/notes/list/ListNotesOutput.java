package com.helha.backend.Application.notes.list;

public record ListNotesOutput(
        long id,
        String name
) {}
