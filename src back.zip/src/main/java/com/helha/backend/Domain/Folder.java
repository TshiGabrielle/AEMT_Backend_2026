package com.helha.backend.Domain;

//Classe représentant un dossier

public class Folder {
    private int  id;
    private String name;
    private int idUser; //propriétaire du dossier
    private int idParent; //dossier parent

}
