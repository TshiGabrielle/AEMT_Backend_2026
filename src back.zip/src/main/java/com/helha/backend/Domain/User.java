package com.helha.backend.Domain;

//Classe représentant un user

public class User {

    private int id;
    private String pseudo;
    private String password;


}
